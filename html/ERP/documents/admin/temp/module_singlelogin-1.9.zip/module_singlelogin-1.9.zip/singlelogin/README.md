Single Login At One Time module for Dolibarr
=========

This module is use to allow only one dolibarr connexion per login.
In other words, two user cannot be connected at the same time with the same login.

This module is publish under licence GPL3 (see COPYING file)

Contact : florian.henry@open-concept.pro
Website : www.open-concept.pro

--------------------------------------


Ce module limite la connexion a une session par login 
Autrement dit deux utilisateurs ne peuvent pas se connecter en même temps avec le même login.

Ce module est sous license GPL3 (voir le fichier COPYING)

Contact : florian.henry@open-concept.pro
Website : www.open-concept.pro
