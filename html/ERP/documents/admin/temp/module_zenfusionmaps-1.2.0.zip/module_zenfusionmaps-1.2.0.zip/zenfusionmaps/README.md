ZenFusion Maps
==============

A Google Maps module for Dolibarr.

Functions
---------

Simply adds a nice icon and a link to Google Maps to addresses for:
- Thirdparties
- Contacts
- Members

Prerequisites
-------------

- PHP ≥ 5.3.0
- Dolibarr ≥ 3.5.0

License
-------

Copyright (C) 2013-2016 GPC.solutions

GPLv3 or (at your option) any later version.

See COPYING for more information.
