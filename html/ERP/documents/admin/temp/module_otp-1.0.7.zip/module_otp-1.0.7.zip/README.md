dolibarr-otp
============

HOTP implementation for Dolibarr

### How to install
Just copy the folder otp to your htdocs folder or your custom folder (if you have configured an alternative path for external modules)

### Minimum requirements
* Mcrypt extension
* Dolibarr 3.3
* PHP 5.3

### Tested Dolibarr versions
* 3.9
* 3.8
* 3.7
* 3.6
* 3.5
* 3.4
* 3.3
